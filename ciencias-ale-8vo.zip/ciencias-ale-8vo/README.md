# Ciencias Ale - 8.º año

Aula de estudio de Ciencias: temas con llaves, ejercicios para resolver, refuerzo de errores, simulacro de 60 puntos y progreso.

## Archivos
- `index.html`: la página.
- `netlify/functions/progreso.mjs`: guarda y lee el progreso en la nube (Netlify Blobs).
- `package.json` y `netlify.toml`: configuración para Netlify.

## Códigos de acceso (obligatorio)
En Netlify: Site configuration → Environment variables → Add a variable:
- `CODIGO_ALE`: el código de Ale (guarda progreso).
- `CODIGO_FAMILIA`: el código de la familia (solo ve el progreso).

Después: Deploys → Trigger deploy → Deploy site.
