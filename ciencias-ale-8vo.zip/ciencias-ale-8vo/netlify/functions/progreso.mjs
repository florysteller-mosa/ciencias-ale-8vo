import { getStore } from "@netlify/blobs";

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

export default async (req) => {
  const ALE = process.env.CODIGO_ALE;
  const FAMILIA = process.env.CODIGO_FAMILIA;
  if (!ALE || !FAMILIA) return json({ error: "Faltan los códigos en Netlify (CODIGO_ALE y CODIGO_FAMILIA)." }, 500);

  const code = (req.headers.get("x-code") || "").trim();
  const role = code === ALE ? "ale" : code === FAMILIA ? "familia" : null;
  if (!role) return json({ error: "codigo" }, 401);

  const store = getStore({ name: "aula-ciencias", consistency: "strong" });

  if (req.method === "GET") {
    const data = await store.get("ale", { type: "json" });
    return json({ role, data: data || null });
  }
  if (req.method === "PUT") {
    if (role !== "ale") return json({ error: "solo lectura" }, 403);
    const text = await req.text();
    if (text.length > 300000) return json({ error: "demasiado grande" }, 413);
    let body;
    try { body = JSON.parse(text); } catch { return json({ error: "datos" }, 400); }
    if (!body || typeof body !== "object" || Array.isArray(body)) return json({ error: "datos" }, 400);
    await store.setJSON("ale", body);
    return json({ ok: true });
  }
  return json({ error: "metodo" }, 405);
};

export const config = { path: "/api/progreso" };
